const { Pool } = require('pg');

// Database configuration (replace with your actual database configuration)
const pool = new Pool({
    host: 'your_db_host',
    user: 'your_db_user',
    password: 'your_db_password',
    database: 'your_db_name',
    port: 5432, // default PostgreSQL port
});

class MxDb {
    constructor() {
        this.con = pool;
        this.dbReset();
    }

    dbReset() {
        this.pre = "mx_";
        this.table = this.sql = this.pkName = this.types = "";
        this.insertID = this.updatedID = this.numRows = this.affectedRows = 0;
        this.data = this.row = this.rows = this.cols = this.vals = this.parentFld = [];
        this.hasLang = this.skipOrg = false;
    }

    getParseType(type = "") {
        const arrParse = {
            "b": ["bytea"],
            "i": ["smallint", "integer", "bigint", "boolean"],
            "d": ["numeric", "real", "double precision"],
        };
        let p = "s";
        if (type) {
            for (let k in arrParse) {
                if (arrParse[k].includes(type)) {
                    p = k;
                    break;
                }
            }
        }
        return p;
    }

    async parseIn(table = "") {
        this.cols = [];
        this.vals = [];
        this.types = "";
        this.hasLang = false;

        const sql = `SELECT column_name, data_type, column_default, is_nullable FROM information_schema.columns WHERE table_name = '${table}'`;
        const res = await this.con.query(sql);

        for (let col of res.rows) {
            let type = col.data_type;
            let name = col.column_name;

            if (name === 'id') this.pkName = name;
            if (name === 'langChild') this.hasLang = true;

            if (this.data.hasOwnProperty(name)) {
                let val = this.data[name];
                if ((!val || val === "") && !col.column_default) val = null;

                this.cols.push(name);
                this.vals.push(val);
                this.types += this.getParseType(type);
            }
        }
    }

    async dbInsert() {
        if (this.data && Array.isArray(this.data)) {
            await this.parseIn(this.table);
            this.sql = `INSERT INTO ${this.table} (${this.cols.join(', ')}) VALUES (${this.cols.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING id`;
            if (this.vals.length > 0) {
                const res = await this.dbExecute();
                if (res) {
                    this.insertID = res.rows[0].id;
                    if (this.hasLang) await this.updateLangChild(this.insertID, "I");
                    return true;
                }
            }
        }
        return false;
    }

    async dbUpdate(whereSql = "", whereTypes = "", whereVals = []) {
        if (this.data && Array.isArray(this.data)) {
            await this.parseIn(this.table);

            if (whereVals.length > 0) {
                this.vals = this.vals.concat(whereVals);
                this.types += whereTypes;
            }

            if (this.vals.length > 0) {
                this.sql = `UPDATE ${this.table} SET ${this.cols.map((col, i) => `${col} = $${i + 1}`).join(', ')} WHERE ${whereSql} RETURNING id`;
                const res = await this.dbExecute();
                if (res) {
                    this.updatedID = res.rows[0].id;
                    if (this.hasLang) await this.updateLangChild(this.updatedID, "U");
                    return true;
                }
            }
        }
        return false;
    }

    async dbQuery() {
        this.rows = [];
        this.row = {};
        const res = await this.dbExecute();
        if (res) {
            this.rows = res.rows;
            this.numRows = res.rowCount;
            return true;
        }
        return false;
    }

    async dbRows() {
        this.rows = [];
        const res = await this.dbExecute();
        if (res) {
            this.rows = res.rows;
            this.numRows = res.rowCount;
        }
        return this.rows;
    }

    async dbRow() {
        this.row = {};
        const res = await this.dbExecute();
        if (res) {
            if (res.rowCount > 0) this.row = res.rows[0];
        }
        return this.row;
    }

    mxWhereIn(strIn = "", type = "s") {
        let str = "";
        if (strIn && strIn.trim() !== "") {
            let s = strIn.split(",");
            for (let v of s) {
                this.vals.push(v);
                this.types += type;
            }
            str = s.map((_, i) => `$${this.vals.length - s.length + i + 1}`).join(", ");
        }
        return str;
    }

    dbBind() {
        // In `pg` we bind parameters directly in the query using $1, $2, etc.
    }

    async dbExecute() {
        if (this.sql && this.sql.trim() !== "") {
            const res = await this.con.query(this.sql, this.vals);
            this.affectedRows = res.rowCount;
            return res;
        }
        return null;
    }

    showSql() {
        if (this.vals.length && this.types !== '') {
            let sql = this.sql;
            let arrTypes = [...this.types];
            arrTypes.forEach((type, k) => {
                let val = this.vals[k];
                if (type === "s") val = `'${val}'`;
                sql = sql.replace(/\?/, val);
            });
            console.log(`\n${sql}\n`);
        }
    }

    async ifTableExists(table) {
        const res = await this.con.query(`SELECT to_regclass('${table}')`);
        return res.rows[0].to_regclass !== null;
    }

    async dbLogActionAddUpdate(actionType = 0) {
        // Implement logging functionality if needed
    }

    async updateLangChild(parentLID = 0, action = "I") {
        // Implement multilingual functionality if needed
    }
}

module.exports = MxDb;
