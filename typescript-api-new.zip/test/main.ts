import { Pool, PoolClient } from 'pg';

interface MXSET {
  MULTILINGUAL: number;
  LANGTYPE: number;
  LOGACTIONDAYS: number;
  LOGIGNORETBL: string;
  MXLOGINKEY: string;
}

declare global {
  var MXSET: MXSET;
  var DB_CONN: Pool;
  var SITEURL: string;
}

class MxDb {
  private con: Pool;
  private client: PoolClient | null = null;
  private pre: string;
  private table: string;
  private sql: string;
  private data: Record<string, any>;
  private insertID: number;
  private updatedID: number;
  private numRows: number;
  private rows: Record<string, any>[];
  private row: Record<string, any>;
  private affectedRows: number;
  private types: string;
  private vals: any[];
  private cols: string[];
  private parentFld: any[];
  private skipOrg: boolean;
  private hasLang: boolean;
  private pkName: string;

  constructor() {
    this.con = global.DB_CONN;
    this.dbReset();
  }

  private async dbReset() {
    this.pre = 'mx_';
    this.table = this.sql = this.pkName = this.types = '';
    this.insertID = this.updatedID = this.numRows = this.affectedRows = 0;
    this.data = this.row = this.rows = this.cols = this.vals = this.parentFld = [];
    this.hasLang = this.skipOrg = false;
  }

  private getParseType(type: string): string {
    const arrParse: Record<string, string[]> = {
      b: ['bytea'],
      i: ['smallint', 'integer', 'bigint', 'boolean'],
      d: ['numeric', 'real', 'double precision'],
      s: ['character varying', 'text', 'uuid', 'timestamp without time zone'],
    };
    let p = 's';
    if (type) {
      for (const [key, value] of Object.entries(arrParse)) {
        if (value.includes(type)) {
          p = key;
          break;
        }
      }
    }
    return p;
  }

  private async parseIn(table: string) {
    this.cols = [];
    this.vals = [];
    this.types = '';
    this.hasLang = false;

    const sql = `SELECT column_name, data_type, column_default, is_nullable, is_identity FROM information_schema.columns WHERE table_name = '${table}'`;
    const result = await this.con.query(sql);
    for (const col of result.rows) {
      const type = col.data_type;
      const name = col.column_name;

      if (col.is_identity === 'YES') this.pkName = name;
      if (name === 'langChild') this.hasLang = true;

      if (Object.prototype.hasOwnProperty.call(this.data, name)) {
        let val = this.data[name];
        if ((!val || val === '') && !col.column_default) val = null;

        this.cols.push(name);
        this.vals.push(val);
        this.types += this.getParseType(type);
      }
    }
  }

  public async dbInsert(): Promise<boolean> {
    if (this.data && Object.keys(this.data).length > 0) {
      await this.parseIn(this.table);
      if (global.MXSET.MULTILINGUAL === 1 && parseInt(global.MXSET.MULTILINGUAL) > 0) {
        const flg = await this.updateLangChild(parseInt(global.MXSET.MULTILINGUAL), 'I');
        if (flg === 1) {
          return true;
        } else {
          return false;
        }
      } else {
        this.sql = `INSERT INTO "${this.table}" (${this.cols.join(',')}) VALUES (${this.cols.map(() => '?').join(',')})`;
        if (this.vals.length > 0) {
          if (await this.dbExecute()) {
            await this.dbLogActionAddUpdate(0);
            if (this.hasLang) await this.updateLangChild(this.insertID, 'I');
            this.dbClose();
            return true;
          } else {
            this.dbClose();
          }
        }
      }
    }
    return false;
  }

  public async dbUpdate(whereSql: string, whereTypes: string, whereVal: any[]): Promise<boolean> {
    if (this.data && Object.keys(this.data).length > 0) {
      await this.parseIn(this.table);
      if (global.MXSET.MULTILINGUAL === 1 && parseInt(global.MXSET.MULTILINGUAL) > 0) {
        if (this.hasLang) {
          const flg = await this.updateLangChild(parseInt(global.MXSET.MULTILINGUAL), 'U');
          if (flg === 1) {
            return true;
          } else {
            return false;
          }
        }
      } else {
        this.vals.push(...whereVal);
        this.types += whereTypes;

        if (this.vals.length > 0) {
          this.sql = `UPDATE "${this.table}" SET ${this.cols.map(col => `${col} = ?`).join(',')} WHERE ${whereSql}`;
          if (await this.dbExecute()) {
            this.dbClose();
            this.vals = whereVal;
            this.types = whereTypes;
            this.sql = `SELECT MAX(${this.pkName}) AS ${this.pkName} FROM "${this.table}" WHERE ${whereSql}`;
            const row = await this.dbRow();
            this.updatedID = row[this.pkName];
            await this.dbLogActionAddUpdate(1);
            if (this.hasLang) await this.updateLangChild(this.updatedID, 'U');
            return true;
          } else {
            this.dbClose();
          }
        }
      }
    }
    return false;
  }

  public async dbQuery(): Promise<boolean> {
    this.rows = [];
    this.row = {};
    if (await this.dbExecute()) {
      const result = await this.client!.query(this.sql, this.vals);
      this.affectedRows = result.rowCount;
      this.numRows = result.rowCount;
      this.dbClose();
      return true;
    } else {
      this.dbClose();
    }
    return false;
  }

  public async dbRows(): Promise<Record<string, any>[]> {
    this.rows = [];
    if (await this.dbExecute()) {
      const result = await this.client!.query(this.sql, this.vals);
      this.numRows = result.rowCount;
      this.rows = result.rows;
    }
    this.dbClose();
    return this.rows;
  }

  public async dbRow(): Promise<Record<string, any>> {
    this.row = {};
    if (await this.dbExecute()) {
      const result = await this.client!.query(this.sql, this.vals);
      this.numRows = result.rowCount;
      if (this.numRows > 0) {
        this.row = result.rows[0];
      }
    }
    this.dbClose();
    return this.row;
  }

  public mxWhereIn(strIn: string, type: string = 's'): string {
    let str = '';
    if (strIn && strIn.trim() !== '') {
      const s = strIn.split(',');
      for (const v of s) {
        this.vals.push(v);
        this.types += type;
      }
      str = s.map(() => '?').join(',');
    }
    return str;
  }

  private dbBind() {
    // pg module handles binding internally
  }

  private async dbExecute(): Promise<boolean> {
    this.client = await this.con.connect();
    try {
      await this.client.query('SET SQL_MODE = \'\'');
      if (this.sql && this.sql.trim() !== '') {
        const result = await this.client.query(this.sql, this.vals);
        this.affectedRows = result.rowCount;
        this.insertID = (result.rows[0] && result.rows[0].id) ? result.rows[0].id : 0;
        return true;
      }
    } catch (error) {
      console.error('Database execution error:', error);
      return false;
    }
    return false;
  }

  private dbClose() {
    this.sql = this.types = '';
    this.vals = [];
    if (this.client) {
      this.client.release();
      this.client = null;
    }
  }

  public showSql() {
    if (this.vals.length > 0 && this.types !== '') {
      let sql = this.sql;
      for (const [index, type] of Array.from(this.types).entries()) {
        let val = this.vals[index];
        if (type === 's') val = `'${val}'`;
        sql = sql.replace('?', val);
      }
      console.log('\n' + sql + '\n');
    }
  }

  private getAlias(): string {
    let alias = '';
    if (this.sql && this.sql !== '') {
      const string = this.sql.replace(/\s+/g, ' ');
      const start = string.indexOf('SELECT') + 7;
      const end = string.indexOf(' FROM');
      alias = string.substring(start, end).trim();
    }
    return alias;
  }

  private async updateLangChild(pkValue: number, actionType: string): Promise<number> {
    const table = this.table + 'Lang';
    if (pkValue > 0 && table) {
      this.cols = [];
      this.vals = [];
      const idFld = this.pkName;
      const childFld = 'langChild';
      this.sql = `SELECT * FROM "${table}" WHERE ${idFld} = ${pkValue}`;
      const res = await this.dbRows();

      if (actionType === 'I') {
        const langArr = global.MXSET.LANGTYPE.split(',');
        const colFld = res.length > 0 ? Object.keys(res[0]) : [];
        for (const val of langArr) {
          const idVal = parseInt(val);
          if (!res.some((item) => item.langChild === idVal)) {
            this.sql = `INSERT INTO "${table}" (${this.pkName}, ${childFld}) VALUES (?,?)`;
            this.vals.push(pkValue, idVal);
            if (await this.dbExecute()) this.dbClose();
          }
        }
      } else if (actionType === 'U' && res.length > 0) {
        for (const row of res) {
          this.sql = `UPDATE "${table}" SET ${this.cols.map(col => `${col} = ?`).join(',')} WHERE ${idFld} = ${pkValue} AND ${childFld} = ${row.langChild}`;
          this.vals.push(pkValue, row.langChild);
          if (await this.dbExecute()) this.dbClose();
        }
      }
    }
    return 1;
  }

  private async dbLogActionAddUpdate(flag: number) {
    const logIgnoreTbl = global.MXSET.LOGIGNORETBL.toLowerCase();
    if (global.MXSET.LOGACTIONDAYS > 0 && !logIgnoreTbl.includes(this.table.toLowerCase())) {
      const primaryKey = flag === 0 ? this.insertID : this.updatedID;
      if (primaryKey > 0) {
        const now = new Date();
        const action = flag === 0 ? 'A' : 'U';
        const strID = this.getAlias();
        const siteUrl = global.SITEURL;
        const url = `${siteUrl}${siteUrl.includes('?') ? '&' : '?'}c=${this.table}&action=${action}&id=${primaryKey}&idName=${this.pkName}&idStr=${strID}`;
        this.sql = `INSERT INTO "log_action" ("logActionDT", "logActionTB", "logActionRecID", "logActionStr", "logActionType") VALUES ($1, $2, $3, $4, $5)`;
        this.vals = [now, this.table, primaryKey, url, action];
        await this.dbExecute();
        this.dbClose();
      }
    }
  }
}

export default MxDb;
