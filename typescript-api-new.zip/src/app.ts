import express from 'express';
import { getUser, insertUser, updateUser } from './userController';
const app = express();


app.get('/data',updateUser)

export default app;