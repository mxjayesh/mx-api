import { Pool, PoolConfig, QueryResult } from 'pg';

const access: PoolConfig = {
  host: 'localhost',
  user: 'postgres',
  password: 'mx7733',
  database: 'cms',
  port: 5432,
};

type TableData = { [key: string]: number | string };

export class MxDb {
  private conn: Pool;
  public pre: string | undefined;
  public table: string  = '';
  public sql: string = '';
  public data: TableData | undefined;
  public insertID: number | undefined;
  public updatedID: number | undefined;
  public numRows: number | null | undefined;
  public rows: any[] | undefined;
  public row: any;
  public affectedRows: number | undefined;
  public types: string | undefined;
  public vals: any[] = [];
  public cols: string[] | undefined;
  public skipOrg: boolean | undefined;
  private credentials: PoolConfig;
  private hasConnected: boolean;
  private pkName: string | undefined;
  private dbstmt: any;

  constructor() {
    this.credentials = access;
    this.conn = new Pool(this.credentials);
    this.hasConnected = true;
    this.dbReset();
  }

  private dbReset() {
    this.pre = 'mx_';
    this.table = this.sql = this.pkName = this.types = '';
    this.insertID = this.updatedID = this.numRows = this.affectedRows = 0;
    this.row = this.rows = [];
    this.cols = [];
    this.vals = [];
    this.data = {};
    this.skipOrg = false;
  }

  private ensureConnection() {
    if (!this.hasConnected) {
      this.conn = new Pool(this.credentials);
      this.hasConnected = true;
    }
  }

  private async parseIn(table: string) {
    const res = await this.conn.query(`SELECT column_name, column_default, is_nullable, data_type 
                                       FROM information_schema.columns 
                                       WHERE table_name = $1`, [table]);
    if (res.rows) {
      this.cols = [];
      res.rows.forEach((col: any) => {
        const colName = col.column_name;
        if (col.column_default && col.column_default.startsWith('nextval')) {
          this.pkName = colName;
        }
        if (this.data?.hasOwnProperty(colName)) {
          let val: any = this.data[colName];
          if (val === '' && col.column_default === null) {
            val = null;
          } else if ((val === '' || val == null) && col.column_default !== null) {
            val = col.column_default;
          }
          this.cols?.push(colName);
          this.vals?.push(val);
        }
      });
    }
  }

  private async dbExecute(): Promise<boolean> {
    this.ensureConnection();
    if (this.sql !== '') {
      try {
        const res: QueryResult = await this.conn.query(this.sql, this.vals);
        if (res.rows && res.rows.length > 0) {
          this.rows = res.rows;
          this.numRows = res.rowCount;
          if (res.rows[0] && res.rows[0].id) {
            this.insertID = res.rows[0].id;
          }
        }
        return true;
      } catch (error) {
        console.error('DB Execution Error:', error);
        throw error;
      }
    }
    return false;
  }

  public async dbRows(): Promise<any[] | undefined> {
    try {
      const dbExecute = await this.dbExecute();
      if (!dbExecute) {
        return [];
      }
    } catch (error) {
      console.error('DB Rows Error:', error);
      throw error;
    } finally {
      this.dbClose();
    }
    return this.rows;
  }

  public async dbRow(): Promise<any> {
    try {
      const dbExecute = await this.dbExecute();
      if (!dbExecute) {
        return null;
      }
      this.row = this.rows?.[0];
    } catch (error) {
      console.error('DB Row Error:', error);
      throw error;
    } finally {
      this.dbClose();
    }
    return this.row;
  }

  public async dbUpdate(where: string = '', whereVals: (string | number)[] = []): Promise<boolean> {
    if (this.table !== '') {
        await this.parseIn(this.table);
        if (this.vals.length > 0) {
            const setClause = this.cols?.map((col, index) => `${col}=$${index + 1}`).join(', ');
            const totalParams:any = this.cols?.length;
            const whereClause = where.replace(/\$(\d+)/g, (_, num) => `$${parseInt(num) + totalParams}`);
            this.sql = `UPDATE ${this.table} SET ${setClause} WHERE ${whereClause}`;
            this.vals = [...this.vals, ...whereVals];
            
            const updateStatus = await this.dbExecute();
            this.dbClose();
            return updateStatus;
        }
    }
    return false;
}


  public async dbInsert(): Promise<boolean> {
    if (this.table !== '') {
      await this.parseIn(this.table);
      if (this.vals.length > 0) {
        const valsPl = this.cols?.map((_, index) => `$${index + 1}`).join(',');
        this.sql = `INSERT INTO ${this.table} (${this.cols?.join(',')}) VALUES (${valsPl}) RETURNING id`;
        const insertStatus = await this.dbExecute();
        this.dbClose();
        return insertStatus;
      }
    }
    return false;
  }

  private dbClose() {
    this.conn.end();
    this.hasConnected = false;
  }

  public async dbQuery(): Promise<boolean> {
    const status = await this.dbExecute();
    if (status) {
      return true;
    }
    this.dbClose();
    return false;
  }
}
