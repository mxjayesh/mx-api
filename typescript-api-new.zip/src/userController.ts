import { Request, Response, NextFunction } from "express";
import { MxDb } from "./Db";

const getUser = async(req:Request, res:Response, next:NextFunction) => {
    const DB = new MxDb()
    DB.vals= ['test@gmail.com']
    DB.sql = `SELECT * from mx_users WHERE email = $1`
    const row = await DB.dbRows()
    res.json({count:DB.numRows, data:row})
}


const insertUser = async(req:Request, res:Response, next:NextFunction) => {
    const DB = new MxDb()
    DB.table = 'mx_users'
    DB.data = {
        name:"gaurav",
        email:"gaurav@gmail.com"
    }
    let resspon = await DB.dbInsert()
    res.json({count:resspon})
}

const updateUser = async(req:Request, res:Response, next:NextFunction) => {
    const DB = new MxDb()
    DB.table = 'mx_users'
    DB.data = {
        name:"xxxxx",
        email:"oooooo@gmail.com"
    }
    let isUpdated = await DB.dbUpdate('id=$1 AND name=$2', [3, "xxxxx"])
    res.json({count:isUpdated})
}

export {
    getUser, insertUser, updateUser
}