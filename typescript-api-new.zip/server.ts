import app from "./src/app";

const startServer = () => {
    const port = process.env.port || 3003;

    app.listen(port, () => {
        console.log(`server listening on port : ${port}`)
    })
}

startServer()